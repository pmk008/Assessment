import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PriceComparision {
	
	WebDriver driver ;
	By amazonSearchbox=By.id("twotabsearchtextbox");
	By amazonPrice=By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[4]/div[1]/div[1]/div/span/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div[1]/div/div/a/span[1]/span[2]/span[2]");
	By amazonSubmitButton=By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div/input");
	By flipkartSearchBox=By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input");
	By flipkartPrice=By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[2]/div[2]/div/div/div/a/div[2]/div[2]/div/div/div");
	By flipkartSubmitButton=By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[2]/form/div/button");
	public void amazonSetSearch(String model) {
		driver.findElement(amazonSearchbox).sendKeys(model);
	}
	
	public void flipkartSetSearch(String model) {
		driver.findElement(flipkartSearchBox).sendKeys(model);
	}
	
	@Test
	public void priceCompare() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\91809\\Downloads\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://www.amazon.in");
		amazonSetSearch("iPhone XR (64GB) - Yellow");
		driver.findElement(amazonSubmitButton).click();
		WebElement amazonPriceElement= driver.findElement(amazonPrice);
		String amazonPrice=amazonPriceElement.getText();
		
		driver.get("https://www.flipkart.com/");
		flipkartSetSearch("iPhone XR (64GB) - Yellow");
		driver.findElement(flipkartSubmitButton);
		WebElement flipkartPriceElement= driver.findElement(flipkartPrice);
		String flipkartPrice=flipkartPriceElement.getText();
		
		if(Integer.valueOf(amazonPrice)>Integer.valueOf(flipkartPrice)) {
			System.out.println("Amazon price is high");
		}
		else if(Integer.valueOf(flipkartPrice)>Integer.valueOf(amazonPrice)) {
			System.out.println("Flikart price is high");
		}
	}

}
